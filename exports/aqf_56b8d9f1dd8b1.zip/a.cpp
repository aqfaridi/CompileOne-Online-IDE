#include <iostream>
using namespace std;

int main() {
    int t,n;
    cin>>t;
    while(t--){
        cin>>n;
        cout<<n<<endl;
    }
	cout<<"hello"<<endl;
	return 0;
}
