import os
os.system("cd ..")
os.system("ls")