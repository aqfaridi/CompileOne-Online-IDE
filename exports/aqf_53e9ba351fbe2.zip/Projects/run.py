import os
os.chroot("cat pankaj.html > <html><head></head><body> pankaj</body></html>")