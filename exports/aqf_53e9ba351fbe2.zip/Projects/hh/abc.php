<?php
while (True)
{
    echo "";
}
?>