while True:
    print ""
