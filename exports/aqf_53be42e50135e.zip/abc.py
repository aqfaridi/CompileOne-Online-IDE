while(True):
    print "python"