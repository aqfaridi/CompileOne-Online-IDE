#include <iostream>
using namespace std;

int main() {
	// your code goes here
	return 0;
}






                        
                            
                                
                                    
                                    