using System;

public class Test
{
	public static void Main()
	{
		Console.WriteLine("selam");
	}
}
