# your code goes here
print "hello";