#include <stdio.h>

int main(void) {
printf("hello");
	return 0;
}

