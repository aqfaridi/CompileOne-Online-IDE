import os
os.system("pwd")