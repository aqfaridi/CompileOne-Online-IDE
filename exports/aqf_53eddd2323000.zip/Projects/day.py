from datetime import date, timedelta
for _ in xrange(input()):
    months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
    d, m, y = raw_input().split()
    m = months.index(m) + 1
    d = int(d)
    y = int(y)
    a = date(y, m, d) - timedelta(days=1)
    y, m, d = str(a).split("-")
    m = months[int(m) - 1]
    print int(d), m, int(y)
