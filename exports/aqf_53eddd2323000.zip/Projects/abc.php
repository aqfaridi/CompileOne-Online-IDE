<?php
while(true)
echo "";

?>