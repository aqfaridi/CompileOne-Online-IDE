import java.util.*;
import java.lang.*;
import java.io.*;

class Main
{
	public static void main (String[] args) throws java.lang.Exception
	{
		System.out.print("Hosh Muhammad");// your code goes here
	}
}
